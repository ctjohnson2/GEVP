# GEVP

Code for solving generalized eigenvalue problem for matrix of correlation functions
currently underdevelopment, but most things should work (provided libraries are in correct places) just not optimally
